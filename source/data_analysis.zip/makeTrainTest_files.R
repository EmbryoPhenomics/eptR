# Randomly sample a list of files (each being an individual) and assign to two subgroups for training/testing a model
  # Output is a list of 2: files for training and testing

makeTrainTest_files <- function(files, train = 0.7) {
  
  trainFiles <- sample(files, size = length(files)*train)
  
  allFiles <- cbind(files, files %in% trainFiles)
  testFiles <- allFiles[,1][allFiles[,2] == FALSE]
  
  trainTest <- list(train = trainFiles, 
                    test = testFiles)
  
  return(trainTest)
  
}
