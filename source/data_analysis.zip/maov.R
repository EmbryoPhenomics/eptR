
# A more flexible Multi-ANOVA method for large numbers of response variables
# Note this is not a MANOVA, an ANOVA is computed on each response variable, and the results are returned as a

# Example usage: maov(responseVars = 1:12, predictVar = "group", data = data)

maov <- function(responseVars, predictVar, data) {
  
  result <- list()
  
  Names <- names(data[,responseVars])
  
  for (name in Names) {
    
    result[[name]] <- aov(data[[name]] ~ data[[predictVar]])
    
  }
  
  return(result)
  
}



