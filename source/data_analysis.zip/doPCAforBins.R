# Do PCA for several binning regimes produced through previous methods. 
# Can optionally return plots of the results to a path specified in outpath

# Note this method is only implemented for the 3 temperature groups and is therefore not a generic method


doPCAforBins <- function(path_20, path_25, path_30, bins, plot = FALSE, outpath) {
  
  source("~/Desktop/github /misc_embryoPhenomics/R/data_vis/plot.save.R", local = TRUE)
  source('~/Desktop/github /misc_embryoPhenomics/R/data_wrangling/rescale.R', local = TRUE)
  
  require(ggplot2, quietly = TRUE)
  
  pca_results <- list()
  
  for (i in 1:length(bins)) {
    
    # Per population rescaling 
    mean20 <- read.csv(paste0(path_20, bins[i], ".csv"), header = TRUE)
    mean25 <- read.csv(paste0(path_25, bins[i], ".csv"), header = TRUE)
    mean30 <- read.csv(paste0(path_30, bins[i], ".csv"), header = TRUE)
    
    mean20_rescaled <- rescale(mean20, columns = 3:ncol(mean20))
    mean25_rescaled <- rescale(mean25, columns = 3:ncol(mean25))
    mean30_rescaled <- rescale(mean30, columns = 3:ncol(mean30))
    
    mean_rescaled <- data.frame(group = NA)
    mean_rescaled[1:367,1] <- 20
    mean_rescaled[368:731,1] <- 25
    mean_rescaled[732:1095,1] <- 30
    mean_rescaled$group <- factor(mean_rescaled$group)
    
    mean_rescaled[1:367, 2:ncol(mean20_rescaled)] <- mean20_rescaled[,2:ncol(mean20_rescaled)]
    mean_rescaled[368:731, 2:ncol(mean25_rescaled)] <- mean25_rescaled[,2:ncol(mean25_rescaled)]
    mean_rescaled[732:1095, 2:ncol(mean30_rescaled)] <- mean30_rescaled[,2:ncol(mean30_rescaled)]
    
    mean_rescaled <- na.omit(mean_rescaled)
    
    # PCA
    pca <- prcomp(mean_rescaled[,3:ncol(mean_rescaled)])
    
    allPC <- data.frame(group = mean_rescaled$group, time = mean_rescaled$cols, pca$x[,1:ncol(pca$x)])
    allPC$group <- factor(allPC$group)
    
    # Compute contribution of various PC's
    expl.var <- round(pca$sdev^2/sum(pca$sdev^2)*100)

    if (plot == TRUE) {
  
      pcplot <- ggplot(allPC, aes(PC1, PC2, colour = group)) +
        geom_point() + 
        labs(title = "Mean rescaled power values for various temperature groups",
             subtitle = paste0("PCA transform, bin number = ", bins[i]),
             x = paste("PC1", paste0(expl.var[1], "%")), 
             y = paste("PC2", paste0(expl.var[2], "%"))) + 
        guides(colour = guide_legend(title = "Group:"))
      
      plot.save(pcplot, 
                path = outpath,
                filename = paste0("PCA_bins-", bins[i], ".png"),
                width = 750, 
                height = 550)
      
    } else if (plot == FALSE) {
      
      name <- paste0("bin", bins[i])
      
      pca$x <- allPC
      pca$expl.var <- expl.var
      pca_results[[name]] <- pca
      
    }
    
  }
  
  return(pca_results)
  
}