
plotRaw_FreqOutput_at_hr <- function(array, hr, axisLabels = FALSE, return = "plot", type = "geom_path()") {
  
  if (requireNamespace("ggplot2", quietly = TRUE) & requireNamespace("gridExtra", quietly = TRUE)) {
    
    #============================#
    # --- For signals of 1x1 ----#
    #============================#
    
    if (length(dim(array)) == 3) {
      
      atHR <- array[1:301, 1:2, hr]
      df   <- data.frame(Frequency = atHR[,1], Power = atHR[,2])
      
      if (return == "plot") {
        
        if (isFALSE(axisLabels)) {
          
          ggplot(df, aes(x = Frequency, y = Power)) + 
            eval(parse(text = type)) +
            theme_void()
          
        } else if (isTRUE(axisLabels)) {
          
          ggplot(df, aes(x = Frequency, y = Power)) + 
            eval(parse(text = type)) 
          
        } else {
          
          stop("axisLabels is a logical argument, can only pass TRUE or FALSE.")
          
        }
        
      } else if (return == "grob") {
        
        ggplot(df, aes(x = Frequency, y = Power))
        
      }
      
    #============================#
    # --- For signals of >1x1 ---#
    #============================# 
      
    } else if (length(dim(array)) == 5) {
      
      rows <- dim(array)[3]
      cols <- dim(array)[4]
      
      atHR <- array[1:301, 1:2, 1:rows, 1:cols, hr]
      
      # Split into individual dataframes for blockwise plotting
      dfs <- list()
      
      for (row in 1:rows) {
        for (col in 1:cols) {
          dfname <- paste0("df",row,"x",col)
          dfs[[dfname]] <- data.frame(Frequency = atHR[,,row, col][,1], Power = atHR[,,row,col][,2])
        }
      }
      
      # Compute max power for ylim
      maxPowers <- c()
      for (df in dfs) maxPowers <- append(maxPowers, max(df$Power))
      maxPower <- max(maxPowers)
      
      if (return == "plot") {
        
        if (isFALSE(axisLabels)) {
          
          # Produce individual grob objects for dataframes (ready for plotting)
          plots <- list()
          
          for (i in 1:length(dfs)) {
            plotname <- paste0("p", i)
            plots[[plotname]] <- 
              ggplot(dfs[[i]], aes(Frequency, Power)) + 
              eval(parse(text = type)) +
              ylim(0, maxPower) +
              theme_void()
          }
          
          gridExtra::grid.arrange(grobs = plots, nrow = rows, ncol = cols)
          
        } else if (isTRUE(axisLabels)) {
          
          plots <- list()
          
          for (i in 1:length(dfs)) {
            plotname <- paste0("p", i)
            plots[[plotname]] <- 
              ggplot(dfs[[i]], aes(Frequency, Power)) + 
              eval(parse(text = type)) +
              ylim(0, maxPower) 
          }
          
          gridExtra::grid.arrange(grobs = plots, nrow = rows, ncol = cols)
          
        } else {
          
          stop("axisLabels is a logical argument, can only pass TRUE or FALSE.")
          
        }
        
      } else if (return == "grob") {
        
        # Produce individual grob objects for dataframes (for use with further ggplot modifications)
        grobs <- list()
        
        for (i in 1:length(dfs)) {
          grobname <- paste0("p", i)
          grobs[[grobname]] <- 
            ggplot(dfs[[i]], aes(Frequency, Power)) + 
            ylim(0, maxPower)
        }
        
        return(grobs)
        
      }
      
    }
    
  } else {
    
    stop("Packages ggplot2 and gridExtra are required for this function.")
    
  }
  
}
  