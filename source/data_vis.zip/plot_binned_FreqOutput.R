# Bin a 1x1 array from FreqOutput signals and plot time vs power, for each bin in descending order

# Requires documentation and methods for larger arrays

plot_binned_FreqOutput <- function(data, axisLabels = FALSE, type = "geom_path()", 
                                   return = "plot", scaleToMax = FALSE) {
  
  maxPower <- max(data, na.rm = TRUE)
  minPower <- min(data, na.rm = TRUE)
  
  if (requireNamespace("ggplot2", quietly = TRUE) & requireNamespace("gridExtra", quietly = TRUE)) {
    
    require(ggplot2)
    
    dfs <- list()
    
    for (i in 2:length(names(data))) {
      name <- paste0("bin", i - 1)
      dfs[[name]] <- data.frame(x = data$cols, y = data[[name]])
    }
    
    if (axisLabels == FALSE) {
    
      plots <- list()
      
      for (i in 1:length(dfs)) {
        plotname <- paste0("p", i)
        plots[[plotname]] <- 
          ggplot(dfs[[i]], aes(x = x, y = y)) + 
          eval(parse(text = type)) +
          theme_void() +
          if (isTRUE(scaleToMax)) ylim(minPower, maxPower)
        
      }
      
      gridExtra::grid.arrange(grobs = plots, nrow = length(names(data)) - 1, ncol = 1)
      
    } else if (axisLabels == TRUE) {
      
      plots <- list()
      
      for (i in 1:length(dfs)) {
        plotname <- paste0("p", i)
        plots[[plotname]] <- 
          ggplot(dfs[[i]], aes(x = x, y = y)) + 
          eval(parse(text = type)) +
          labs(x = "Time (Hr)", y = "Power") +
          if (isTRUE(scaleToMax)) ylim(minPower, maxPower)
        
      }
      
      gridExtra::grid.arrange(grobs = plots, nrow = length(names(data)) - 1, ncol = 1)
      
    } else {
      
      stop("axisLabels is a logical argument, can only pass TRUE or FALSE.")
      
    }
    
  } else {
    
    stop("Packages ggplot2 and gridExtra required for this function.")
  
  }
  
}
