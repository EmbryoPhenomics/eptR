# Rescale a dataframe or matrix to 0 - 1, by column or by row - i.e. each column or row is rescaled 
    # independently of other columns or rows. Default is by column. 

rescale <- function(data, columns = 2:ncol(data), rows = 2:nrow(data), byrow = FALSE, bycol = TRUE) {
  
  if (bycol == TRUE & byrow == FALSE) {
    
    for (i in columns) {
      data[,i] <- scale(data[,i],
                        center = min(data[,i], na.rm = TRUE),
                        scale = max(data[,i], na.rm = TRUE) - min(data[,i], na.rm = TRUE))
    }
    
  } else if (byrow == TRUE & bycol == FALSE) {
    
    for (i in rows) {
      data[i,] <- scale(data[i,],
                        center = min(data[i,], na.rm = TRUE),
                        scale = max(data[i,], na.rm = TRUE) - min(data[i,], na.rm = TRUE))
    }
    
  } else {
    
    stop("Can only rescale by rows or by columns, not both.")
    
  }
  
  return(data)
  
}
