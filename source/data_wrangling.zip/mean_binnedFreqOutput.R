# Compute the mean of binned 1x1 frequency arrays
# specify a path to the HDF5 files obtained through EmbryoCV

# Requires documentation

mean_binnedFreqOutput <- function(path, files = NULL, bins) {
  
  if (is.null(files))
    files <- list.files(pattern = ".HDF5", path = path)

  df_all <- list()
  
  for (bin in 1:bins) {
    binName <- paste0("bin", bin)
    df_all[[binName]] <- list()
  }
  
  for (n in names(df_all)) {
    
    for (file in files) {
      
      array <- getXArrayData_basic(paste0(path, file), "FreqOutput_1x1")
      binned_data <- bin_FreqOutput1x1(array, bins = bins)
      
      name <- gsub(".HDF5", "", file)
      df_all[[n]][[name]] <- binned_data[[n]]
      
    }
    
    dims <- lapply(df_all[[n]], length)
    maxDim <- max(unlist(dims), na.rm = TRUE)
    
    df_all[[n]] <- matrix(unlist(df_all[[n]]), ncol = length(df_all[[n]]), nrow = maxDim)
    df_all[[n]] <- rowSums(df_all[[n]], na.rm = TRUE)
    
  }
  
  df <- data.frame(cols = 1:length(df_all[[1]]))
  
  for (i in names(df_all)) df[[i]] <- df_all[[i]]
  
  return(df)
  
}
