
# Retrieve all the FreqOutput_1x1 arrays for every individual listed in files
  # Output is a list of the arrays in matrix format or a dataframe where all individuals are compiled. 

retrieveFiles <- function(files, path, output = "raw", format = "list", group, rescale = TRUE) {
  
  data <- list()
  
  for (i in 1:length(files)) {
    
    array <- getXArrayData_basic(paste0(path, files[i]), "FreqOutput_1x1")
    
    if (output == "matrix")
      dat <- t(array[1:dim(array)[1], 2, 1:dim(array)[3]])
    else if (output == "raw")
      dat <- array
    
    name <- gsub("dataset.HDF5", "", files[i])
    data[[name]] <- dat
  }
  
  if (format == "list") {
    
    return(data)
    
  } else if (format == "dataframe") {
   
    # Calculate length of dataframe row-wise
    times <- data.frame(unlist(lapply(data, nrow)))
    totalTime <- sum(times[,1])
    
    # Compute stfart and end rows for compiling individual data
    rowInfo <- data.frame(numRows = times[,1])
    rowInfo$endRow <- cumsum(rowInfo$numRows)
    rowInfo$startRow <- (rowInfo$endRow - rowInfo$numRows) + 1
    
    # Set up empty dataframe - group included if format option is dataframe
    df <- data.frame(group = rep(group, times = totalTime), embryo = NA)
    df[,3:303] <- NA # 301 is known frequency number
    
    embryoNames <- names(data)
    
    for (i in 1:length(data)) {
      
      if (rescale) 
        df[rowInfo$startRow[i] : rowInfo$endRow[i], 3:303] <- rescale(data[[i]], columns = 1:ncol(data[[i]]))
      else
        df[rowInfo$startRow[i] : rowInfo$endRow[i], 3:303] <- data[[i]]
      
      df[rowInfo$startRow[i] : rowInfo$endRow[i], 2] <- embryoNames[i]
    }
    
    return(df)
     
  } else {
    stop("Format not supported, only output options are list or dataframe.")
  }
  
}

