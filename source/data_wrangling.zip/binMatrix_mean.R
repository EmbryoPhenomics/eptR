# Divide a matrix into bins and return the mean for each bin. Output is in dataframe format with a 
# column for column number

# Requires documentation

binMatrix_mean <- function(matrix, bins) {
  
  if (requireNamespace("magrittr", quietly = TRUE)) {
    
    startRow <- ceiling(seq(1, nrow(matrix), length.out = bins + 1))
    
    endRow <- startRow
    endRow[1] <- NA
    endRow <- na.omit(endRow)
    
    startRow <- startRow + 1
    startRow[1] <- 1
    startRow[length(startRow)] <- NA
    startRow <- na.omit(startRow)
    
    rowInfo <- data.frame(startRow, endRow)
    
    df <- data.frame(cols = 1:ncol(matrix))
    
    for (i in 1:length(rowInfo$startRow)) {
      
      colName <- paste0("bin", i)
      
      binMean <- matrix[rowInfo$startRow[i] : rowInfo$endRow[i], 1:ncol(matrix)] %>%
        colMeans()
      
      df[[colName]] <- binMean
      
    }
    
    return(df)
    
  } else {
    
    stop("magrittr is required for this function.")
    
    
  }
  
}