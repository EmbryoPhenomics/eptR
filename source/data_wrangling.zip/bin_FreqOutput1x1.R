# Bin the Freqeuncy output (1x1) for a single embryo 

bin_FreqOutput1x1 <- function(array, binMethod = "mean", bins = 10, hatchTime = NULL) {
  
  mat <- array[1:dim(array)[1], 2, 1:dim(array)[3]]
  
  if (binMethod == "sum") 
    binnedMat <- binMatrix_sum(matrix = mat, bins = bins)
  else if (binMethod == "mean") 
    binnedMat <- binMatrix_mean(matrix = mat, bins = bins)
  else 
    stop("Only mean and sum type binning methods are supported.")
  
  if (is.null(hatchTime))
    data <- binnedMat
  else
    data <- binnedMat[binnedMat$cols <= hatchTime, ]
  
  return(data)
  
}
