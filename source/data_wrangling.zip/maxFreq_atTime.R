# Compute the frequency with the maximum energy at all time points from a FreqOutput_1x1 array
    # Energy values are rescaled to a uniform index of 0 - 1 within each frequency to prevent 
    # over-representation of lower frequencies

# Requires documentation

maxFreq_atTime <- function(array) {
  
  if (requireNamespace("magrittr", quietly = TRUE)) {
    
    data <- array[1:dim(array)[1], 2, 1:dim(array)[3]] %>%
      rescale(byrow = TRUE, bycol = FALSE) %>%
      data.frame()
    
    data$freq <- array[1:dim(array)[1], 1, median(1:dim(array)[3])]
    
    maxFreq <- data.frame(time = 1:dim(array)[3])
    maxFreq$freq <- NA_integer_
    
    for (i in 1:(ncol(data) - 1))
      maxFreq$freq[i] <- data$freq[data[,i] == max(data[,i], na.rm = TRUE)]
    
    return(maxFreq)
    
    
  } else {
    
    stop("magrittr is required for this function.")
    
  }
  
}
