getXArrayData_basic <- function(file, subdataset) {
  
  if (requireNamespace("ncdf4", quietly = TRUE)) {
    
    data <- ncdf4::nc_open(file)
    
    array <- ncdf4::ncvar_get(data, data$var[[subdataset]])
    
    ncdf4::nc_close(data)
    
    return(array)
    
  } else {
    
    stop("Package ncdf4 is required for this function. Install using install.packages('ncdf4')")
    
  }
  
}
