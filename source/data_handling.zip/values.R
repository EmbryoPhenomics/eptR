# Function for retrieving the values contained in a matrix

values <- function(matrix){
  
  matrix_Vals <- c()
  
  for (i in matrix) matrix_Vals <- append(matrix_Vals, i)
  
  return(matrix_Vals)
  
}


