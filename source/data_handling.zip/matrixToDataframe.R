
# Function for converting a matrix to dataframe format

matrixToDataframe <- function(matrix) {
  
  vals <- values(matrix)
  ncols <- 1:ncol(matrix)
  nrows <- 1:nrow(matrix)
  
  xyz <- data.frame(x = rep.int(x = ncols, times = length(nrows)),
                    y = rep(x = nrows, each = length(ncols)), 
                    z = vals)
  return(xyz)
  
} 

