getEmbryoLabels <- function(path) {
  
  files <- list.files(path = path, pattern = ".HDF5")
  
  onlyEmbryo <- unlist(
    lapply(files, 
           FUN = function(x) gsub("dataset.HDF5", "", x)
           )
    )
  
  return(onlyEmbryo)
  
}

