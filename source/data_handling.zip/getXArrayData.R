getXArrayData <- function(file, subdataset) {
  
  # Requires documentation
  
  fileData <- openXArray(file, path = NULL)
  
  if ("netCDF" %in% unlist(strsplit(fileData$Driver, "/"))) {
    
    if (requireNamespace("ncdf4", quietly = TRUE)) {
      
      data <- ncdf4::nc_open(file)
      
      if (subdataset %in% fileData$SubDataset$ArrayName) {
        
        array <- ncdf4::ncvar_get(data, data$var[[subdataset]])
    
        ncdf4::nc_close(data)
    
        return(array)
        
      } else {
        
        warning("Subdataset not in HDF5 file. Make sure it is one of the above.")
        return(subdata)
        
      }
      
    } else {
      
      stop("Package ncdf4 is required for this function. Install using install.packages('ncdf4')")
      
    }
    
  } else {
    
    stop("Only HDF5 files of format NCDF or netCDF (Network Common Data Format) are supported for this method.")
    
  }
  
}


