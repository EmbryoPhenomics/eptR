openXArray <- function(filename, path = NULL) {
  
  # Requires Documentation
  
  # To do:
  # Include commands for all os's
  
  RawfileData <- system(command = paste("gdalinfo", paste0(path, filename)), 
                        intern = TRUE, 
                        ignore.stdout = FALSE, 
                        ignore.stderr = TRUE, 
                        wait = TRUE)
  
  arrayNamesRaw    <- RawfileData[grep("^.*SUBDATASET.*NAME", RawfileData)]
  arrayNames_split <- unlist(strsplit(arrayNamesRaw, ":"))
  arrayNamesOnly   <- arrayNames_split[seq(3, length(arrayNames_split), 3)]
  
  arrayDescRaw    <- RawfileData[grep("^.*SUBDATASET.*DESC", RawfileData)]
  arrayDesc_split <- unlist(strsplit(arrayDescRaw, "="))
  arrayDimsRaw    <- arrayDesc_split[seq(2, length(arrayDesc_split), 2)]
  arrayDimsOnly   <- sub(" .*", "", arrayDimsRaw)
  
  if (is.null(path)) 
    Location = getwd()
  else 
    Location = path
  
  metadata <- list(
    Location = Location,
    File = filename,
    Driver = gsub("Driver: ", "", RawfileData[1]),
    SubDataset = data.frame(ArrayName = arrayNamesOnly, ArrayDimensions = arrayDimsOnly)
  )
  
  return(metadata)
  
}

